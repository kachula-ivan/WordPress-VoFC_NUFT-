﻿namespace kursova
{
    class Class1
    {
    }
}
