﻿
namespace kursova
{
    partial class AddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cb1 = new System.Windows.Forms.CheckBox();
            this.tbKodAuto = new System.Windows.Forms.TextBox();
            this.tbTypTovaru = new System.Windows.Forms.TextBox();
            this.tbPostachalnyck = new System.Windows.Forms.TextBox();
            this.tbNameTovaru = new System.Windows.Forms.TextBox();
            this.tbKodTovaru = new System.Windows.Forms.TextBox();
            this.tbPrice = new System.Windows.Forms.TextBox();
            this.AddBtn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.товарBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.товарBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Код товару";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Назва товару";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(12, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "Постачальник";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(12, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 29);
            this.label4.TabIndex = 3;
            this.label4.Text = "Тип товару";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(12, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 29);
            this.label5.TabIndex = 4;
            this.label5.Text = "Код авто";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(12, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(169, 29);
            this.label6.TabIndex = 5;
            this.label6.Text = "Ціна продажу";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(12, 183);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 29);
            this.label7.TabIndex = 6;
            this.label7.Text = "Наявність";
            // 
            // cb1
            // 
            this.cb1.AutoSize = true;
            this.cb1.Location = new System.Drawing.Point(215, 192);
            this.cb1.Name = "cb1";
            this.cb1.Size = new System.Drawing.Size(18, 17);
            this.cb1.TabIndex = 7;
            this.cb1.UseVisualStyleBackColor = true;
            // 
            // tbKodAuto
            // 
            this.tbKodAuto.Location = new System.Drawing.Point(215, 132);
            this.tbKodAuto.Name = "tbKodAuto";
            this.tbKodAuto.Size = new System.Drawing.Size(100, 22);
            this.tbKodAuto.TabIndex = 8;
            // 
            // tbTypTovaru
            // 
            this.tbTypTovaru.Location = new System.Drawing.Point(215, 103);
            this.tbTypTovaru.Name = "tbTypTovaru";
            this.tbTypTovaru.Size = new System.Drawing.Size(100, 22);
            this.tbTypTovaru.TabIndex = 9;
            // 
            // tbPostachalnyck
            // 
            this.tbPostachalnyck.Location = new System.Drawing.Point(215, 74);
            this.tbPostachalnyck.Name = "tbPostachalnyck";
            this.tbPostachalnyck.Size = new System.Drawing.Size(100, 22);
            this.tbPostachalnyck.TabIndex = 10;
            // 
            // tbNameTovaru
            // 
            this.tbNameTovaru.Location = new System.Drawing.Point(215, 45);
            this.tbNameTovaru.Name = "tbNameTovaru";
            this.tbNameTovaru.Size = new System.Drawing.Size(100, 22);
            this.tbNameTovaru.TabIndex = 11;
            // 
            // tbKodTovaru
            // 
            this.tbKodTovaru.Location = new System.Drawing.Point(215, 16);
            this.tbKodTovaru.Name = "tbKodTovaru";
            this.tbKodTovaru.Size = new System.Drawing.Size(100, 22);
            this.tbKodTovaru.TabIndex = 12;
            // 
            // tbPrice
            // 
            this.tbPrice.Location = new System.Drawing.Point(215, 164);
            this.tbPrice.Name = "tbPrice";
            this.tbPrice.Size = new System.Drawing.Size(100, 22);
            this.tbPrice.TabIndex = 13;
            // 
            // AddBtn
            // 
            this.AddBtn.Location = new System.Drawing.Point(215, 215);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(110, 38);
            this.AddBtn.TabIndex = 14;
            this.AddBtn.Text = "Додати";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 215);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 38);
            this.button2.TabIndex = 15;
            this.button2.Text = "Скасувати";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // товарBindingSource
            // 
            this.товарBindingSource.DataMember = "Товар";
        
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 265);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.AddBtn);
            this.Controls.Add(this.tbPrice);
            this.Controls.Add(this.tbKodTovaru);
            this.Controls.Add(this.tbNameTovaru);
            this.Controls.Add(this.tbPostachalnyck);
            this.Controls.Add(this.tbTypTovaru);
            this.Controls.Add(this.tbKodAuto);
            this.Controls.Add(this.cb1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AddForm";
            this.Text = "Додати";
            ((System.ComponentModel.ISupportInitialize)(this.товарBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox cb1;
        private System.Windows.Forms.TextBox tbKodAuto;
        private System.Windows.Forms.TextBox tbTypTovaru;
        private System.Windows.Forms.TextBox tbPostachalnyck;
        private System.Windows.Forms.TextBox tbNameTovaru;
        private System.Windows.Forms.TextBox tbKodTovaru;
        private System.Windows.Forms.TextBox tbPrice;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.BindingSource товарBindingSource;
    }
}